// ConsoleApplication11.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

const int maxScaleUp = 100;
int scaleFactor = 1;
int scaleType = 0;
int maxType = 1;
const int max_scale_type = 1;
std::string windowName = "Resize";
std::string trackbarValue = "Scale";
std::string trackbarType = "Type: \n 0: Scale Up \n 1: Scale Down";
cv::Mat Image;

void scaleImage(int, void*) {
	double ScaleFactorDouble = 1 + scaleFactor / 100.0;
	double ScaleFactorDown = 1 - scaleFactor / 100.0;


	
	cv::Mat Resized;
	
	cv::resize(Image, Resized, cv::Size(), ScaleFactorDouble, ScaleFactorDouble, cv::INTER_LINEAR);
	if (scaleType == 1) {
		cv::resize(Image, Resized, cv::Size(), ScaleFactorDown, ScaleFactorDown, cv::INTER_LINEAR);
	}
	
	
	cv::imshow(windowName, Resized);
}

int main() {
	std::string Path = "./Sekiro.jpeg";
	Image = cv::imread(Path);
	cv::resize(Image, Image, cv::Size(1200, 720));
	scaleFactor = 0;
	scaleType = 0;

	
	cv::namedWindow(windowName, cv::WINDOW_AUTOSIZE);

	cv::createTrackbar(trackbarValue, windowName, &scaleFactor, maxScaleUp, scaleImage);
	cv::createTrackbar(trackbarType, windowName, &scaleType, max_scale_type, scaleImage);
	scaleImage(25, 0);

	cv::waitKey(0);
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
